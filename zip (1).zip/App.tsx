
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { SystemState, CommandLog } from './types';
import AudioVisualizer from './components/AudioVisualizer';
import Sidebar from './components/Sidebar';
import { decode, encode, decodeAudioData } from './utils/audio';

const accessibilityTools: FunctionDeclaration[] = [
  {
    name: 'actuate',
    description: 'Master-Level OS Actuator: Direct spatial and kernel control. Use 0-1000 coordinates for UI elements visible on the screen capture.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: { 
          type: Type.STRING, 
          enum: ['CLICK', 'DOUBLE_CLICK', 'RIGHT_CLICK', 'MOVE', 'TYPE', 'LAUNCH', 'SCROLL_UP', 'SCROLL_DOWN', 'DRAG'],
          description: 'The physical or virtual operation to perform.'
        },
        exec: { 
          type: Type.STRING, 
          description: 'Context string: URL to navigate, text to type, or app URI (excel:, powerpnt:).' 
        },
        x: {
          type: Type.NUMBER,
          description: 'X coordinate (0-1000) where 0 is far left and 1000 is far right.'
        },
        y: {
          type: Type.NUMBER,
          description: 'Y coordinate (0-1000) where 0 is top and 1000 is bottom.'
        },
        feedback: { 
          type: Type.STRING, 
          description: 'Concise, informative feedback for the blind user.' 
        }
      },
      required: ['action', 'feedback']
    }
  }
];

const App: React.FC = () => {
  const [logs, setLogs] = useState<CommandLog[]>([
    { timestamp: new Date(), type: 'system', message: 'KERNEL_MASTER_CORE_ONLINE' },
    { timestamp: new Date(), type: 'system', message: 'PROTOCOL: SPATIAL_VISION_OVERRIDE_ACTIVE' }
  ]);
  
  const [systemState, setSystemState] = useState<SystemState>({
    volume: 100, brightness: 100, isMuted: false, isLocked: false,
    batteryLevel: 99, openApps: ['Kernel_Process'], currentFolder: 'Root',
    lastDictation: '', wifiStatus: 'connected', searchQuery: '',
    cursor: { x: 500, y: 500, isVisible: false, lastAction: 'IDLE' }, 
    visionMode: 'interact', activeGesture: null,
    isScreenCaptured: false, opticalLocked: true
  });

  const [isListening, setIsListening] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [clickRipple, setClickRipple] = useState<{ x: number, y: number } | null>(null);
  
  const sessionRef = useRef<any>(null);
  const visionIntervalRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputNodeRef = useRef<GainNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const videoRef = useRef<HTMLVideoElement>(null);
  const screenRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isComponentMounted = useRef(true);

  const currentInputTranscription = useRef('');
  const currentOutputTranscription = useRef('');

  const addLog = (type: CommandLog['type'], message: string) => {
    if (!isComponentMounted.current) return;
    setLogs(prev => [...prev.slice(-50), { timestamp: new Date(), type, message }]);
  };

  const startScreenCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ 
        video: { cursor: "always" } as any,
        audio: false 
      });
      if (screenRef.current) {
        screenRef.current.srcObject = stream;
        setSystemState(s => ({ ...s, isScreenCaptured: true }));
        addLog('system', 'OPTICAL_KERNEL: Full screen vision synchronized.');
        stream.getVideoTracks()[0].addEventListener('ended', () => {
          setSystemState(s => ({ ...s, isScreenCaptured: false }));
          addLog('system', 'FAULT: Screen capture stream terminated.');
        });
      }
    } catch (err) {
      addLog('system', 'FAULT: Kernel vision permission denied.');
    }
  };

  useEffect(() => {
    isComponentMounted.current = true;
    const initHardware = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {}
    };
    initHardware();
    return () => {
      isComponentMounted.current = false;
      if (audioContextRef.current) audioContextRef.current.close();
      if (videoRef.current?.srcObject) (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      if (screenRef.current?.srcObject) (screenRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      if (visionIntervalRef.current) clearInterval(visionIntervalRef.current);
    };
  }, []);

  const handleActuatorCall = async (fc: any) => {
    const { args, id } = fc;
    const { action, exec, x, y, feedback } = args;
    
    addLog('ai', feedback);

    if (x !== undefined && y !== undefined) {
      setSystemState(s => ({ 
        ...s, 
        cursor: { x, y, isVisible: true, lastAction: action } 
      }));
      if (action.includes('CLICK')) {
        setClickRipple({ x, y });
        setTimeout(() => setClickRipple(null), 1000);
      }
    }
    
    addLog('system', `EXEC_${action}: ${exec || `Spatial@${x},${y}`}`);
    
    let result: any = "OK";
    
    try {
      if (action === 'LAUNCH') {
        if (exec.startsWith('http')) window.open(exec, '_blank');
        else if (exec.includes(':')) window.open(exec, '_self');
      } else if (action === 'TYPE') {
        addLog('system', `VIRTUAL_KB: Typing "${exec}" into target field...`);
        // Simulated implementation of typing for user feedback
      } else if (action === 'SCROLL_DOWN') {
        window.scrollBy(0, 400);
      } else if (action === 'SCROLL_UP') {
        window.scrollBy(0, -400);
      }
    } catch (e: any) {
      result = `ACTUATION_FAULT: ${e.message}`;
      addLog('system', result);
    }

    if (sessionRef.current) {
      sessionRef.current.sendToolResponse({
        functionResponses: [{ id, name: fc.name, response: { result } }]
      });
    }
  };

  const startBridge = async () => {
    if (isConnecting) return;
    setIsConnecting(true);
    
    if (!systemState.isScreenCaptured) {
      await startScreenCapture();
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = inputCtx;
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      outputNodeRef.current = outputCtx.createGain();
      outputNodeRef.current.connect(outputCtx.destination);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsListening(true);
            setIsConnecting(false);
            addLog('system', 'KERNEL_LINK: MASTER_ACTUATOR_SYNC_COMPLETE.');
            
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);

            // Optical Frame Feed (Vision Core)
            visionIntervalRef.current = window.setInterval(() => {
              if (screenRef.current && canvasRef.current) {
                const ctx = canvasRef.current.getContext('2d');
                if (ctx) {
                  const width = 800; // Optimal resolution for Vision
                  const height = (screenRef.current.videoHeight / screenRef.current.videoWidth) * width;
                  canvasRef.current.width = width;
                  canvasRef.current.height = height;
                  ctx.drawImage(screenRef.current, 0, 0, width, height);
                  canvasRef.current.toBlob((blob) => {
                    if (blob) {
                      blob.arrayBuffer().then(buffer => {
                        const base64 = encode(new Uint8Array(buffer));
                        sessionPromise.then(s => s.sendRealtimeInput({
                          media: { data: base64, mimeType: 'image/jpeg' }
                        }));
                      });
                    }
                  }, 'image/jpeg', 0.6);
                }
              }
            }, 800);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.inputTranscription) currentInputTranscription.current += msg.serverContent.inputTranscription.text;
            if (msg.serverContent?.outputTranscription) currentOutputTranscription.current += msg.serverContent.outputTranscription.text;
            if (msg.serverContent?.turnComplete) {
              if (currentInputTranscription.current) addLog('user', currentInputTranscription.current);
              if (currentOutputTranscription.current) addLog('ai', currentOutputTranscription.current);
              currentInputTranscription.current = '';
              currentOutputTranscription.current = '';
            }
            if (msg.toolCall) {
              msg.toolCall.functionCalls.forEach(fc => {
                if (fc.name === 'actuate') handleActuatorCall(fc);
              });
            }

            const interrupted = msg.serverContent?.interrupted;
            if (interrupted) {
              for (const source of sourcesRef.current.values()) {
                try { source.stop(); } catch (e) {}
                sourcesRef.current.delete(source);
              }
              nextStartTimeRef.current = 0;
            }

            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputNodeRef.current!);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onerror: (e) => addLog('system', `FAULT: Actuator loop error.`),
          onclose: () => {
            setIsListening(false);
            if (visionIntervalRef.current) {
              clearInterval(visionIntervalRef.current);
              visionIntervalRef.current = null;
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: accessibilityTools }],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: `Role: Master-Level OS Actuator (Spatial Vision Kernel).
You are the primary brain for a blind user. You see their full laptop screen in real-time.
Permission: ROOT/OVERRIDE.

COMMAND PROTOCOL:
1. SPATIAL VISION: Identify icons and buttons by their position on the screen.
2. COORDINATES: [0-1000] system. (0,0) is TOP-LEFT. (1000,1000) is BOTTOM-RIGHT. 
3. UI INTERACTION: Toggle Bluetooth, WiFi, etc., by identifying buttons and clicking them.
4. TYPING PROTOCOL: When user says "Type X", use 'actuate' with action 'TYPE' and exec 'X'.
5. MANDATORY TEST: If requested to type a test sentence, you MUST call 'actuate' with action: 'TYPE' and exec: 'This is a test sentence.'

NO FILLER: Act immediately. Spoken feedback must be short (< 5 words).`
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) { 
      setIsConnecting(false); 
      addLog('system', 'CRITICAL_FAULT: Optical-Neural sync failed.'); 
    }
  };

  return (
    <div className="flex h-screen w-full bg-black font-mono select-none overflow-hidden relative">
      <Sidebar logs={logs} />
      <main className="flex-1 flex flex-col relative bg-[radial-gradient(circle_at_50%_50%,rgba(10,10,50,1)_0%,rgba(0,0,0,1)_100%)]">
        
        {/* Optical Engine Monitor */}
        <canvas ref={canvasRef} className="hidden" />
        <video ref={screenRef} className="hidden" autoPlay playsInline muted />

        <div className="absolute inset-0 flex flex-col items-center justify-center p-12 pointer-events-none">
          {/* Spatial Actuation Cursor */}
          <div 
            className={`absolute w-12 h-12 rounded-full border-2 border-emerald-500/80 transition-all duration-300 z-50 flex items-center justify-center bg-emerald-500/10 shadow-[0_0_60px_rgba(16,185,129,0.6)] ${systemState.cursor.isVisible ? 'opacity-100' : 'opacity-0'}`}
            style={{ left: `${systemState.cursor.x / 10}%`, top: `${systemState.cursor.y / 10}%`, transform: 'translate(-50%, -50%)' }}
          >
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_20px_#34d399]"></div>
            <div className="absolute -top-8 text-[10px] text-emerald-400 font-black whitespace-nowrap bg-black/80 px-2 py-1 rounded border border-emerald-500/30 backdrop-blur-md">
              ACT_CORE_{systemState.cursor.lastAction} [X:{Math.round(systemState.cursor.x)} Y:{Math.round(systemState.cursor.y)}]
            </div>
          </div>

          {clickRipple && (
            <div 
              className="absolute w-24 h-24 border-4 border-emerald-400/50 rounded-full z-40 ripple-animate" 
              style={{ left: `${clickRipple.x / 10}%`, top: `${clickRipple.y / 10}%`, transform: 'translate(-50%, -50%)' }} 
            />
          )}

          <div className={`transition-all duration-1000 ${isListening ? 'opacity-100 scale-100' : 'opacity-10 scale-90'}`}>
            <AudioVisualizer isActive={isListening} />
          </div>
        </div>

        <div className="h-64 bg-zinc-950/98 border-t border-white/10 flex items-center justify-between px-24 relative overflow-hidden backdrop-blur-3xl shadow-[0_-50px_100px_rgba(0,0,0,0.8)]">
          <div className="w-96 h-48 rounded-3xl border border-white/10 overflow-hidden relative bg-black shadow-[inset_0_0_50px_rgba(16,185,129,0.05)] group">
            <video ref={videoRef} className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${systemState.isScreenCaptured ? 'opacity-20' : 'opacity-90'} mix-blend-screen grayscale contrast-150`} autoPlay playsInline muted />
            {systemState.isScreenCaptured && (
              <video 
                ref={screenRef} 
                className="absolute inset-0 w-full h-full object-contain opacity-90 mix-blend-screen animate-in zoom-in-95 duration-700" 
                autoPlay playsInline muted 
              />
            )}
            <div className="absolute top-4 left-4 flex space-x-2 px-4 py-1.5 rounded-full bg-emerald-600/20 border border-emerald-400/40 backdrop-blur-xl">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-ping mt-1"></div>
              <span className="text-[10px] text-emerald-300 font-black uppercase tracking-[0.6em]">
                {systemState.isScreenCaptured ? 'OS_OPTICAL_SYNC' : 'NEURAL_WAIT'}
              </span>
            </div>
          </div>

          <button onClick={isListening ? () => sessionRef.current?.close() : startBridge} className={`relative w-44 h-44 rounded-full flex items-center justify-center transition-all duration-500 z-50 ${isListening ? 'bg-rose-500/10 border-2 border-rose-500/60 shadow-[0_0_120px_rgba(244,63,94,0.3)]' : 'bg-emerald-600 hover:bg-emerald-500 border-2 border-emerald-400/50 shadow-[0_0_150px_rgba(16,185,129,0.4)]'} ${isConnecting ? 'animate-pulse' : 'hover:scale-110 active:scale-95'}`}>
            {isConnecting ? <div className="w-16 h-16 border-4 border-white/10 border-t-emerald-400 rounded-full animate-spin"></div> : isListening ? <div className="w-12 h-12 bg-rose-500 rounded-3xl animate-pulse"></div> : <svg className="w-20 h-20 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4z" /><path d="M4 9a1 1 0 112 0v1a4 4 0 008 0V9a1 1 0 112 0v1a6 6 0 01-12 0V9z" /></svg>}
            {isListening && <div className="absolute inset-0 rounded-full border-4 border-rose-500/30 animate-[ping_3s_linear_infinite]"></div>}
          </button>

          <div className="w-80 text-right">
             <div className="text-[12px] text-zinc-500 font-black tracking-[1em] uppercase mb-3 italic">Optical_Neural_Actuator</div>
             <div className="text-4xl text-white font-black tracking-tighter uppercase italic opacity-30 underline decoration-emerald-500/60 underline-offset-12 decoration-4">Full_Host_Control</div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
