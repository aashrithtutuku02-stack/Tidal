
import React, { useEffect, useState } from 'react';

interface AudioVisualizerProps {
  isActive: boolean;
}

const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ isActive }) => {
  const [bars, setBars] = useState<number[]>(new Array(32).fill(2));

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setBars(new Array(32).fill(0).map(() => Math.floor(Math.random() * 40) + 2));
      }, 80);
    } else {
      setBars(new Array(32).fill(2));
    }
    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <div className="flex items-center space-x-1 h-12">
      {bars.map((height, i) => (
        <div
          key={i}
          className={`w-[2px] rounded-full transition-all duration-100 ${isActive ? 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]' : 'bg-zinc-900'}`}
          style={{ height: isActive ? `${height}px` : '2px', opacity: isActive ? 1 : 0.2 }}
        ></div>
      ))}
    </div>
  );
};

export default AudioVisualizer;
