
import React, { useRef, useEffect } from 'react';
import { CommandLog } from '../types';

interface SidebarProps {
  logs: CommandLog[];
}

const Sidebar: React.FC<SidebarProps> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <aside className="w-[420px] bg-zinc-950 border-r border-white/10 flex flex-col p-12 shadow-[50px_0_100px_rgba(0,0,0,0.9)] z-20">
      <div className="flex items-center space-x-5 mb-16">
        <div className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_20px_#10b981]"></div>
        <span className="text-[12px] font-black text-emerald-500 uppercase tracking-[0.6em]">System Master Link Active</span>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-8 font-mono text-[12px] scroll-smooth pr-6 custom-scrollbar"
      >
        {logs.map((log, i) => (
          <div key={i} className={`p-8 rounded-3xl border transition-all duration-700 hover:scale-[1.02] ${
            log.type === 'system' ? 'bg-zinc-900/50 border-white/5 text-zinc-400' :
            log.type === 'user' ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-100 shadow-[0_0_30px_rgba(16,185,129,0.05)]' :
            'bg-indigo-500/5 border-indigo-500/20 text-indigo-200'
          }`}>
            <div className="flex items-center justify-between mb-5">
              <span className={`text-[10px] font-black uppercase tracking-[0.4em] ${
                log.type === 'system' ? 'text-zinc-600' :
                log.type === 'user' ? 'text-emerald-500' :
                'text-indigo-500'
              }`}>
                {log.type}
              </span>
              <span className="text-[9px] text-zinc-800 font-bold">
                {log.timestamp.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
            <p className="leading-relaxed opacity-90 italic font-medium tracking-tight whitespace-pre-wrap">{log.message}</p>
          </div>
        ))}
      </div>

      <div className="mt-16 pt-16 border-t border-white/10">
        <h3 className="text-[11px] font-black text-zinc-600 mb-10 uppercase tracking-[0.8em]">Host Integration Status</h3>
        <div className="space-y-6 text-[11px] font-mono">
          <div className="flex justify-between items-center group">
            <span className="text-zinc-500 uppercase tracking-tighter group-hover:text-zinc-300 transition-colors">Optical_Core_Sync</span>
            <span className="text-emerald-500 font-black shadow-[0_0_10px_rgba(16,185,129,0.2)]">STABLE</span>
          </div>
          <div className="flex justify-between items-center group">
            <span className="text-zinc-500 uppercase tracking-tighter group-hover:text-zinc-300 transition-colors">Spatial_Actuation</span>
            <span className="text-emerald-500 font-black">ENABLED</span>
          </div>
          <div className="flex justify-between items-center group">
            <span className="text-zinc-500 uppercase tracking-tighter group-hover:text-zinc-300 transition-colors">Kernel_Bridge</span>
            <span className="text-indigo-500 font-black">OVERRIDE_MODE</span>
          </div>
          <div className="flex justify-between items-center group">
            <span className="text-zinc-500 uppercase tracking-tighter group-hover:text-zinc-300 transition-colors">Neural_Pathing</span>
            <span className="text-emerald-500 font-black">ULTRA_LOW_LATENCY</span>
          </div>
        </div>
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #27272a; border-radius: 20px; }
      `}</style>
    </aside>
  );
};

export default Sidebar;
